let walls = [];
let wallsNull = [];
let rays1 = []; let x1, x2, y1, y2, ri, extractX; 
let div = 20; let slider, sliderRaysNo; 

let ray;
let particle;
let xoff = 0;
let yoff = 100;

let bx; let by; 
let XOffset = 0; 
let YOffset = 0; overObjWa = false; overObjWb = false; overObj = false; locked = false; let lockedWa = false; let lockedWb = false; 
let prismX = 0;
let prismY = 0;
let errW = 15; let err = 15; // err is pixels
let indexa, indexb, XOffseta = 0, XOffsetb = 0, YOffseta = 0, YOffsetb = 0;
// let ang = 0;

//// Here there are three main classses defined, 1) boundary.js [defining the properties of each and every surface], 2) particle.js [defining the properties of 
//// light source and other essential source-surface interactions], 3) ray.js [constructs rays from the point source]. NOTE: In this code surface means a line. But in futute surface can also be an curve.
let tool = 0;
let btnSrc;
let btnRay;
let btnPrism;
var isSourceSelected = false;
var isRaySelected = false;  
var isPrismSelected = false;
var isSourceDragged = false;

function selectSrc() {
  isSourceSelected = true;
  isSourceDragged = false;
  btnSrc.style('background-color', 'gray');
  //btnRay.style('background-color', 'black');
  btnPrism.style('background-color', 'black');
  //TODO btnSrc.style('background-image', 'LightSourceSel.jpg');
  //document.getElementById("log").value = "Source Selected\n";
  locked = true;
  overObj = true;
  overObjWa = false;
  lockedWa = false;
}
function selectRay() {
  //isSourceSelected = false;
  //isRaySelected = true;
  //isPrismSelected = false;
  btnSrc.style('background-color', 'black');
  //btnRay.style('background-color', 'gray');
  btnPrism.style('background-color', 'black');
  //document.getElementById("log").value = "Ray Selected\n";
}

function selectPrism() {
  isPrismSelected = true;
  btnSrc.style('background-color', 'black');
  //btnRay.style('background-color', 'black');
  btnPrism.style('background-color', 'gray');
  //document.getElementById("log").value = "Prism Selected\n";
  locked = false;
  overObj = false;
  overObjWa = true;
  lockedWa = true;
}
function updatePrismWalls(cx, cy, h){
 ///////new surfaces are created to form a wheel 
 
 		var i = -1;
		for (wall of walls){
			i++;
			if (i >= 4 && i < 14){
				walls[i].b.x = cx;
				walls[i].b.y = cy;
			}
			else if (i == 14){
				if (isPrismSelected){walls[i].a.x = cx - 250;walls[i].a.y = h/2;}
				else {walls[i].a.x = 0;walls[i].a.y = 0;}
				if (isPrismSelected){walls[i].b.x = cx - 250;walls[i].b.y = h;}
				else {walls[i].b.x = 0;walls[i].b.y = 0;}
			}
			else if (i == 15){
				if (isPrismSelected){walls[i].a.x = cx - 100; walls[i].a.y = h/2;}
				else {walls[i].a.x = 0;walls[i].a.y = 0;}
				if (isPrismSelected){walls[i].b.x = cx - 100; walls[i].b.y = h;}
				else {walls[i].b.x = 0;walls[i].b.y = 0;}
			}
			else if (i == 16){
				if (isPrismSelected){walls[i].a.x = cx - 50; walls[i].a.y = h/2;}
				else {walls[i].a.x = 0; walls[i].a.y = 0;}
				if (isPrismSelected){walls[i].b.x = cx - 50;walls[i].b.y = h;}
				else {walls[i].b.x = 0;walls[i].b.y = 0;}
			}
		}
}


// function setup runs once.
function setup() {
	let btnPos = 0;
	btnSrc = button = createImg('LightSource.jpg');//createButton('LightSource');
	btnSrc.position(0, btnPos);
	btnSrc.size(99,99);
	btnSrc.style('background-color', 'black');
	btnSrc.style('color', 'white');
	btnSrc.mousePressed(selectSrc);
  
	btnPos = btnPos + btnSrc.height + 1;
	btnPrism = createImg('MirrorObject.jpg');//createButton('Prism');
	btnPrism.position(0, btnPos);
	btnPrism.size(99,99);
	btnPrism.style('background-color', 'black');
	btnPrism.style('color', 'white');
	btnPrism.mousePressed(selectPrism);
	/*
	btnPos = btnPos + btnPrism.height + 1;
	btnRay = createButton('Ray');
	btnRay.position(0, btnPos);
	btnRay.size(99,99);
	btnRay.style('background-color', 'black');
	btnRay.style('color', 'white');
	btnRay.mousePressed(selectRay);	
	*/
    canvas2 = createCanvas(700, 700);
    canvas2.position(100, 0);	
    slider = createSlider(0, 360, 10, 1);
	slider.position(100, canvas2.height);
    sliderRaysDen = createSlider(1, 5, 1, 1);
	sliderRaysDen.position(100 + slider.width, canvas2.height);

      //new surfaces are created along the canvas boundaries. We call them "canvas boundary walls".
      walls.push(new Boundary(0,0,width,0,1)); // Boundary(x1,y1,x2,y2); arguments are endpoints of a line (surface)
      walls.push(new Boundary(width,0,width,height,1));
      walls.push(new Boundary(width,height,0,height,1));
      walls.push(new Boundary(0,height,0,0,1));

      // new surfaces are created at random positions.
    // for (let i = 4; i < 7; i++){
    //     x1 = random(width);
    //     x2 = random(width);
    //     y1 = random(height);
    //     y2 = random(height);
    //     ri = random(1,2);

    //     walls[i] = new Boundary(x1,y1,x2,y2,ri);

    // }
  ///////new surfaces are created to form a wheel 
  for (let i = 4; i < 14; i += 1){ // start from 4 always
        x1 = width/2 + 300 * Math.cos(radians(20*(i-13))); 
		y1 = height/2+ 300 * Math.sin(radians(20*(i-13)));

        x2 = width/2; 
		y2 = height/2;

        ri = (i-3)/2;

        walls[i] = new Boundary(x1, y1, x2, y2, ri);
    }
    //////// new surfaces are created to form a square
    // walls.push(new Boundary(100,100,200,100,1));
    // walls.push(new Boundary(200,100,200,200,1));
    // walls.push(new Boundary(200,200,100,200,1));
    // walls.push(new Boundary(100,200,100,100,1));

//document.getElementById("log").value = "x2 " + x2 +" y2 " + y2 + "\n";

    ///////new surfaces are created fixed vertical walls
    //walls.push(new Boundary(100, height/2, 100, height, 1.5));
	walls.push(new Boundary((x2 - 250), height/2, (x2 - 250), height, 1.5));
    //walls.push(new Boundary(250, height/2, 250, height, 2));
	walls.push(new Boundary((x2 - 100), height/2, (x2 - 100), height, 2));
    //walls.push(new Boundary(300, height/2, 300, height, 1.5));
	walls.push(new Boundary((x2 - 50), height/2, (x2 - 50), height, 1.5));
	
	//updatePrismWalls(x2, y2, height);
	updatePrismWalls(0, 0, height);

    particle = new Particle(slider.value(), 1); // creating a light source using particle.js class. Takes the default slider value for divergence with 'ray density' 1. The position of this default particle is 
    // width/2, height/2. See particle constructor in class particle.js
    bx = width/2;
    by = height/2;
    particle.update(bx,by); // update the position of particle as bx, by
}

function drawSource(){ // runs at every ~33ms in a loop
//document.getElementById("log").value = "Draw\n";
    background(0); // canvas background color
    particle = new Particle(slider.value(), sliderRaysDen.value()); // particle divergence and ray density are dynamically taken from silders 'slider.value()' and 'sliderRaysDen.value()'.
    
    // showing walls on canvas
    for (wall of walls){
		// prismSG
        if (isPrismSelected)wall.show(); // wall is an element in the arrays of surfaces 'walls'. wall.show() calls the function show() from the class boundary.js
    }


    //////////////////////////////
    //CURRENTLY UNDER DEBUGGING
    // extracting the both end (a and b) x,y of all walls
    //LONG CODE (DO NOT DELETE)
    extractXa = walls.map(({a}) => a).map(({x}) => x); //walls.map(({a}) => a) takes all 'a' property array from walls array. Then all x are taken from 'a' arrray. 
    extractXb = walls.map(({b}) => b).map(({x}) => x);
    extractYa = walls.map(({a}) => a).map(({y}) => y);
    extractYb = walls.map(({b}) => b).map(({y}) => y);


    //SHORT CODE: 
    // extractXa = walls.map(({a}) => a).map(({x}) => x).concat(walls.map(({b}) => b).map(({x}) => x)); // array of X of all wall-ends
    // extractYa = walls.map(({a}) => a).map(({y}) => y).concat(walls.map(({b}) => b).map(({y}) => y)); // array of Y of all wall-ends
    /////////////////////////////

    // Checking whether mouse hovers on the source or not. 'err' defines how close the mouse should be near to the source.
    /*if (mouseX > bx - err && mouseX < bx + err && mouseY < by + err && mouseY > by - err){
        overObj = true;
    } else{
        overObj = false;
    }*/
    particle.update(bx,by); // update source position

    ///THE PHYSICS ENGINE
    if (isSourceDragged)particle.multiBoundaries(walls); // this does the calculations involving refraction of rays through every surface.
}


function draw(){ // runs at every ~33ms in a loop
	if (isSourceSelected || isPrismSelected)drawSource();
	else background(0);
}

///ADDITIONAL FUNCTIONS

// Please refer p5 references for explanation of functions mousePressed, mouseReleased and mouseDragged.
function mousePressed(){
	if (mouseX < 0 || mouseY < 0) return;
	if (mouseX > bx - err && mouseX < bx + err && mouseY < by + err && mouseY > by - err){
        overObj = true;
    } else{
        overObj = false;
    }
    if (overObj){ // priority is source while source and wall end are ovelapping.
        locked = true;
        XOffset = mouseX-bx;
        YOffset = mouseY-by;
        ///////////
        //UNDER DEBUGGING
        
    } else if (overObjWa){
        lockedWa = true;
        XOffseta = mouseX - walls[indexa].a.x;
        YOffseta = mouseY - walls[indexa].a.y;

    } else if (overObjWb){
        lockedWb = true;
        Xoffsetb = mouseX-walls[indexb].b.x;
        Yoffsetb = mouseY-walls[indexb].b.y;
        ///////////
    } 
    else {
        locked = false; lockedWa = false; lockedWb = false;
    }
    

}


// 
function mouseDragged(){
//document.getElementById("log").value = "mouseDragged " + lockedWa + " \n";
//document.getElementById("log").value += "mouseDragged mouseX " + mouseX + " " + mouseY + " \n";
//document.getElementById("log").value += "mouseDragged XOffseta " + XOffseta + " " + YOffseta + " \n";
	if (isSourceSelected){
		isSourceDragged = true;
	}
    if (locked){
        bx = mouseX - XOffset;
        by = mouseY - YOffset;
    } else if (lockedWa) {
        ///////////
        //UNDER DEBUGGING
		updatePrismWalls(mouseX - XOffseta, mouseY - YOffseta, height);
        //walls[indexa].a.x = mouseX - XOffseta;		
        //walls[indexa].a.y = mouseY - YOffseta;
    } else if (lockedWb) {
        walls[indexb].b.x = mouseX - Xoffsetb;
        walls[indexb].b.y = mouseY - YOffsetb;
    }   ///////////
}

function mouseReleased() {
    locked = false;
    lockedWa = false; lockedWb = false;
  }

  //To draw arrows for ray-lines instead of plain lines. NOT USED FOR CURRENT CODE. BUT COULD BE USED LATER.
function drawArrow(base, vec, myColor) {
    push();
    stroke(myColor);
    strokeWeight(3);
    fill(myColor);
    // translate(base.x, base.y);
    line(base.x, base.y,vec.x, vec.y);
    rotate(vec.heading());
    let arrowSize = 3;
    translate(vec.mag() - arrowSize, 0);
    triangle(0, arrowSize / 2, 0, -arrowSize / 2, arrowSize, 0);
    pop();
  }
  ///////////////////
  // UNDER DEBUGGING

  function checkWallEnd(arr, x, errW){
    arr.some(function(element, index) {
        // console.log(element);
        
        if(x > element - errW && x < element + errW){
            return true;}
        else{
            return false;}
        });
    }

    function checkWallEndIndex(arr, x, errW){
        arr.some(function(element, index) {
            // console.log(element);
            
            if(x > element - errW && x < element + errW){ // this should be always true;
                return index;
            }
            else {
                print("check this")
            }
           
            });
    }  ///////////////////

  

