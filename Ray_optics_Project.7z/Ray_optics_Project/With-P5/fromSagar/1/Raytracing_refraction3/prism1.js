// Creating objects: LightRay, Prism
class LightRay
{
	constructor(){
        this.startX = 0;  // Starting point of LightRay
        this.startY = 0;
        this.intrSecX = 0; // Point at which LightRay intersects on Prism
        this.intrSecY = 0;
        this.refrctnX = 0; // End point of refracted ray
        this.refrctnY = 0;
        this.reflctnX = 0; // End point of reflected ray
        this.reflctnY = 0;
        this.endX = 0; // End point of ray if it is not reflected or refracted.
        this.endY = 0;
	
		this.distance = 0;  // Length of ray between ray-source and reflection/refraction point.
	}
};

class Prism
{
	constructor(){
		this.side1StartX = 0; // Starting point of Side1 of Prism
		this.side1StartY = 0;
		this.side1EndX = 0;   // End point of Side1
		this.side1EndY = 0;
		this.side2StartX = 0;  // Start point of Side2
		this.side2StartY = 0;
		this.side2EndX = 0;    // End point of Side2
		this.side2EndY = 0;
		this.side3StartX = 0;   // Start point of Side3
		this.side3StartY = 0;
		this.side3EndX = 0;    // End point of Side3
		this.side3EndY = 0;
		this.side4StartX = 0;   // Start point of Side4
		this.side4StartY = 0;
		this.side4EndX = 0;      // End point of Side4
		this.side4EndY = 0;	 
	}
};

const ray1 = new LightRay();
const prism1 = new Prism();

var intersectPrism = false;  // Flag to check whether ray intersects with Prism.
var intrSecX = 0;            // Intersecting point.
var intrSecY = 0;

var isClicked = false;  // Flag to check whether mouse is pressed.

var infinite = 0;       // Infinite value to draw lengthy ray.

var isRaySelected = true;  // Flag indicating which tool is selected.
var isPrismSelected = false;

function onLoad() { 
	infinite = Math.hypot(window.innerWidth, window.innerHeight); // Infinite value to calculate lengthy ray.
}

function selectTool(){
	var tool = document.getElementById("ray");
	isRaySelected = tool.checked;
	tool = document.getElementById("prism");
	isPrismSelected = tool.checked;
}

function findPointAngle(x1, y1, x2, y2) {  // Finds angle between two points. 
  var dy = y2 - y1;
  var dx = x2 - x1;
  var radian = Math.atan2(dy, dx);
  return radian;
}

function findLineAngle(l1x1, l1y1, l1x2, l1y2, l2x1, l2y1, l2x2, l2y2) {// Finds angle between two lines. [angle between ray and prism surface]
	var dAx = l1x2 - l1x1;
	var dAy = l1y2 - l1y1;
	var dBx = l2x2 - l2x1;
	var dBy = l2y2 - l2y1;
	var radian =  Math.atan2(dAx * dBy - dAy * dBx, dAx * dBx + dAy * dBy);
	return radian;
}

function canvasMouseDown(event) {  // Mouse down handler

	if (isRaySelected) {
		if (!isClicked){   // New ray is starting on canvas; initializing LightRay.startX and LightRay.startY
			ray1.startX = event.clientX;
			ray1.startY = event.clientY;
			ray1.distance = 0;
			isClicked = true;
			intersectPrism = false;
		}
		else{	// Second time clicked on canvas. nothing to do (Fixes the LightRay).
			isClicked = false;
		}
	}
	else if (isPrismSelected) { // New Prism is starting on canvas; initializing Starting point of side1
		if (!isClicked){
			prism1.side1StartX = event.clientX;
			prism1.side1StartY = event.clientY;
			isClicked = true;
		}
		else{	// Second time clicked on canvas. nothing to do(Fixes the prism).
			isClicked = false;
		}
	}
}

function canvasMouseMove(event) {   // Mouse move handler
	if (isRaySelected) {
		if (isClicked){
			var rayAngle = findPointAngle(ray1.startX, ray1.startY, event.clientX, event.clientY);
			ray1.endX = Math.cos(rayAngle) * (infinite); // Finds endpoint for ray to draw lengthy ray
			ray1.endY = Math.sin(rayAngle) * (infinite);
			checkPrismIntersection();  // Checks ray intersects with prism.
			draw();						// Draws ray with calculated x, y values.
		}
	}
	else if (isPrismSelected){
		if (isClicked){
			prism1.side1EndX = event.clientX;
			prism1.side1EndY = event.clientY;
			checkPrismIntersection();
            draw();	
		}
	}
}

function draw(){
	var canvas = document.getElementById('mycanvas');
	var ctx = canvas.getContext('2d');
	ctx.clearRect(0, 0, canvas.width, canvas.height);

	ctx.beginPath();
	ctx.moveTo(ray1.startX, ray1.startY);
	if (intersectPrism){
		ctx.lineTo(ray1.intrSecX, ray1.intrSecY);
		if (ray1.refrctnX != 0 && ray1.refrctnY != 0){ // Refraction is only-if ray starts from outside of prism.
			ctx.lineTo(ray1.refrctnX, ray1.refrctnY);
		}
		ctx.lineTo(ray1.reflctnX, ray1.reflctnY);
	}
	else{
		ctx.lineTo(ray1.endX, ray1.endY);
	}
	ctx.strokeStyle = "yellow";
	ctx.stroke();
    drawPrism(ctx);
}

function drawPrism(ctx){  // Draw prism with 4 sides.
	var dx = 0;
	var dy = 0;
	var nextX = 0;
	var nextY = 0;
	var endX = prism1.side1EndX;
	var endY = prism1.side1EndY;
	var startX = prism1.side1StartX;
	var startY = prism1.side1StartY;
	// Draw Side 1 of prism
	ctx.beginPath();
	ctx.moveTo(startX, startY);
	ctx.lineTo(endX, endY);
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	// Draw Side 2 of prism
	ctx.lineTo(nextX, nextY);
	prism1.side2StartX = startX;
	prism1.side2StartY = startY;
	prism1.side2EndX = nextX;
	prism1.side2EndY = nextY;

	endX = prism1.side1StartX;
	endY = prism1.side1StartY;
	startX = nextX;
	startY = nextY;
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	// Draw Side 3 of prism
	ctx.lineTo(nextX, nextY);
	prism1.side3StartX = startX;
	prism1.side3StartY = startY;
	prism1.side3EndX = nextX;
	prism1.side3EndY = nextY;	

	endX = startX;
	endY = startY;
	startX = nextX;
	startY = nextY;
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	// Draw Side 4 of prism
	ctx.lineTo(nextX, nextY);
	prism1.side4StartX = startX;
	prism1.side4StartY = startY;
	prism1.side4EndX = nextX;
	prism1.side4EndY = nextY;	
	
	ctx.strokeStyle = "white";
	ctx.stroke();	
	ctx.closePath();
}

function checkPrismIntersection() {
	var refrStartX = 0;
	var refrStartY = 0;
	var refrEndX = 0;
	var refrEndY = 0;

	var reflStartX = 0;
	var reflStartY = 0;
	var reflEndX = 0;
	var reflEndY = 0;
	
	ray1.distance = 0;
	ray1.reflctnX = 0;
	ray1.reflctnY = 0;
	ray1.refrctnX = 0;
	ray1.refrctnY = 0;
	
	intersectPrism = false;
	// To check ray is originating from outside or inside of prism.
	// If LightRay is originating from Inside of Prism, then Reflection only (No refraction)
	if ((prism1.side1StartX < ray1.startX && ray1.startX < prism1.side3EndX) && 
	    (prism1.side1StartY < ray1.startY && ray1.startY < prism1.side3EndY) ){
		document.getElementById("log").value = "LightRay Inside. Only reflection and no Refraction\n";
		// Checks LightRay intersects at Side1 of prism 
		var intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
		prism1.side1StartX, prism1.side1StartY,  prism1.side1EndX, prism1.side1EndY);
		if (intersect){
			document.getElementById("log").value += "Side1 intersects\n";
			ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
			ray1.intrSecX = intrSecX;  // Intersecting point
			ray1.intrSecY = intrSecY;
			refrStartX = prism1.side1StartX;
			refrStartY = prism1.side1StartY;
			refrEndX = prism1.side1EndX;
			refrEndY = prism1.side1EndY;
		}
		else{
			// Checks LightRay intersects at Side2 of prism 
			intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
			prism1.side2StartX, prism1.side2StartY,  prism1.side2EndX, prism1.side2EndY);
			
			if (intersect){
				document.getElementById("log").value += "Side2 intersects\n";
				ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
				ray1.intrSecX = intrSecX;
				ray1.intrSecY = intrSecY;
				refrStartX = prism1.side2StartX;
				refrStartY = prism1.side2StartY;
				refrEndX = prism1.side2EndX;
				refrEndY = prism1.side2EndY;
			}
			else{
				intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
				prism1.side3StartX, prism1.side3StartY,  prism1.side3EndX, prism1.side3EndY);

				if (intersect){
					document.getElementById("log").value = "Side3 intersects\n";
					ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
					ray1.intrSecX = intrSecX;
					ray1.intrSecY = intrSecY;
					refrStartX = prism1.side3StartX;
					refrStartY = prism1.side3StartY;
					refrEndX = prism1.side3EndX;
					refrEndY = prism1.side3EndY;
				}
				else{
					intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
					prism1.side4StartX, prism1.side4StartY,  prism1.side4EndX, prism1.side4EndY);
					
					if (intersect){
						document.getElementById("log").value += "Side4 intersects\n";
						ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
						ray1.distance = distance;
						ray1.intrSecX = intrSecX;
						ray1.intrSecY = intrSecY;
						refrStartX = prism1.side4StartX;
						refrStartY = prism1.side4StartY;
						refrEndX = prism1.side4EndX;
						refrEndY = prism1.side4EndY;
					}
				}
			}
		}
		
		if (intersect){  // LightRay was intersected on any of side.
			intersectPrism = true;
			// Finds angle between ray and intersected surface
			var intersecAngle = findLineAngle(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
											  refrStartX, refrStartY, refrEndX, refrEndY);
			// Finds angle of  intersected surface
			var sideAngle = findPointAngle(refrStartX, refrStartY, refrEndX, refrEndY);
			var reflAngle = (sideAngle + intersecAngle);
			// End point of reflected ray.
			ray1.reflctnX = Number(ray1.intrSecX) + Number(Math.cos(reflAngle) * (infinite));
			ray1.reflctnY = Number(ray1.intrSecY) + Number(Math.sin(reflAngle) * (infinite));		
	
			document.getElementById("log").value += "Side InterSecAngle " + intersecAngle * 180/Math.PI;
			document.getElementById("log").value += "\nsideAngle " + sideAngle * 180/Math.PI;
			document.getElementById("log").value += "\nreflAngle " + reflAngle * 180/Math.PI + "\n";
			document.getElementById("log").value += "reflctnX " + ray1.reflctnX + " reflctnY " + ray1.reflctnY + "\n";
			return; // No refraction since ray is from inside of prism. hence returns.
		}
	}
	else{
		document.getElementById("log").value = "LightRay Outside. Reflection & Refraction";
	}
// Starts refraction calculation.
	// Checks whether ray intersects with side1 of prism.
	var intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
	prism1.side1StartX, prism1.side1StartY,  prism1.side1EndX, prism1.side1EndY);
	if (intersect){
		ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		ray1.intrSecX = intrSecX;
		ray1.intrSecY = intrSecY;
		refrStartX = prism1.side1StartX;
		refrStartY = prism1.side1StartY;
		refrEndX = prism1.side1EndX;
		refrEndY = prism1.side1EndY;
	}
	// Checks whether ray intersects with side2 of prism.
	intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
	prism1.side2StartX, prism1.side2StartY,  prism1.side2EndX, prism1.side2EndY);
	
	if (intersect){
		var distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		if ((distance < ray1.distance) || (ray1.distance == 0)){
			// if length of ray intersects on Side2 is less than length of side1, then, ray is nearer to side2.
			// hence refraction is on side2.
			ray1.distance = distance;
			ray1.intrSecX = intrSecX;
			ray1.intrSecY = intrSecY;
			refrStartX = prism1.side2StartX;
			refrStartY = prism1.side2StartY;
			refrEndX = prism1.side2EndX;
			refrEndY = prism1.side2EndY;
		}
	}
	intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
	prism1.side3StartX, prism1.side3StartY,  prism1.side3EndX, prism1.side3EndY);
	
	if (intersect){
		var distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		if ((distance < ray1.distance) || (ray1.distance == 0)){
			// if length of ray intersects on Side3 is less than length of side2, then, ray is nearer to side3.
			// hence refraction is on side3.		
			ray1.distance = distance;
			ray1.intrSecX = intrSecX;
			ray1.intrSecY = intrSecY;
			refrStartX = prism1.side3StartX;
			refrStartY = prism1.side3StartY;
			refrEndX = prism1.side3EndX;
			refrEndY = prism1.side3EndY;
		}
	}
	intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
	prism1.side4StartX, prism1.side4StartY,  prism1.side4EndX, prism1.side4EndY);
	
	if (intersect){
		var distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		if ((distance < ray1.distance) || (ray1.distance == 0)){
			ray1.distance = distance;
			ray1.intrSecX = intrSecX;
			ray1.intrSecY = intrSecY;
			refrStartX = prism1.side4StartX;
			refrStartY = prism1.side4StartY;
			refrEndX = prism1.side4EndX;
			refrEndY = prism1.side4EndY;
		}
	}	

	if (ray1.distance != 0){ // Is refraction happened on any of side.
		intersectPrism = true;
		// Finds angle of ray.
		var rayAngle = findPointAngle(ray1.startX, ray1.startY, ray1.intrSecX, ray1.intrSecY);
		
		rayAngle = rayAngle + (20 * Math.PI/180); // refraction angle is set to 20Degree (assuming constant angle)
		// finds refraction end point at 20Degree from intersection point; at infinite.
		ray1.refrctnX = Number(ray1.intrSecX) + Number(Math.cos(rayAngle) * (infinite));
		ray1.refrctnY = Number(ray1.intrSecY) + Number(Math.sin(rayAngle) * (infinite));
		//document.getElementById("log").value += "\nrayAngle " + rayAngle * 180/Math.PI + "\n";		
		//document.getElementById("log").value += "refrctnX " + ray1.refrctnX + " refrctnY " + ray1.refrctnY + "\n";
	}
	else{
		intersectPrism = false;
		document.getElementById("log").value = "";
	}
	
// Reflection calculation starts.
	if ((refrStartX != prism1.side1StartX) || // If ray refracted on Side1, it will not reflected on side1 again.
	    (refrStartY != prism1.side1StartY) || // hence ensures refraction-side is not the reflection side.
		(refrEndX != prism1.side1EndX) ||
		(refrEndY != prism1.side1EndY)){
		// Checks refracted line intersects on Side1 of prism
		intersect = checkLineIntersection(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
		prism1.side1StartX, prism1.side1StartY, prism1.side1EndX, prism1.side1EndY);
		if (intersect){
			ray1.refrctnX = intrSecX;
			ray1.refrctnY = intrSecY;
			ray1.distance = Math.hypot(ray1.startX - ray1.refrctnX, ray1.startY - ray1.refrctnY);
			// Finds angle between ray and reflection side.
			var intersecAngle = findLineAngle(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
											  prism1.side1StartX, prism1.side1StartY, prism1.side1EndX, prism1.side1EndY);
			var sideAngle = findPointAngle(prism1.side1StartX, prism1.side1StartY, prism1.side1EndX, prism1.side1EndY);
			var reflAngle = (sideAngle + intersecAngle);
			ray1.reflctnX = Number(ray1.refrctnX) + Number(Math.cos(reflAngle) * (infinite));
			ray1.reflctnY = Number(ray1.refrctnY) + Number(Math.sin(reflAngle) * (infinite));
/*			
			document.getElementById("log").value = "Side InterSecAngle " + intersecAngle * 180/Math.PI;			
			document.getElementById("log").value += "\nsideAngle " + sideAngle * 180/Math.PI;
			document.getElementById("log").value += "\nreflAngle " + reflAngle * 180/Math.PI + "\n";
			document.getElementById("log").value += "reflctnX " + ray1.reflctnX + " reflctnY " + ray1.reflctnY + "\n";*/
		}
	}
	
	if ((intersect == false) &&
		(refrStartX != prism1.side2StartX) || // ensure reflection side is not refraction side.
	    (refrStartY != prism1.side2StartY) ||
		(refrEndX != prism1.side2EndX) ||
		(refrEndY != prism1.side2EndY)){
		intersect = checkLineIntersection(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
		prism1.side2StartX, prism1.side2StartY, prism1.side2EndX, prism1.side2EndY);
		if (intersect){
			ray1.refrctnX = intrSecX;
			ray1.refrctnY = intrSecY;
			ray1.distance = Math.hypot(ray1.startX - ray1.refrctnX, ray1.startY - ray1.refrctnY);

			var intersecAngle = findLineAngle(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
											  prism1.side2StartX, prism1.side2StartY, prism1.side2EndX, prism1.side2EndY);
			var sideAngle = findPointAngle(prism1.side2StartX, prism1.side2StartY, prism1.side2EndX, prism1.side2EndY);
			var reflAngle = (sideAngle + intersecAngle);
			ray1.reflctnX = Number(ray1.refrctnX) + Number(Math.cos(reflAngle) * (infinite));
			ray1.reflctnY = Number(ray1.refrctnY) + Number(Math.sin(reflAngle) * (infinite));
			/*document.getElementById("log").value = "Side InterSecAngle " + intersecAngle * 180/Math.PI;
			document.getElementById("log").value += "\nsideAngle " + sideAngle * 180/Math.PI;
			document.getElementById("log").value += "\nreflAngle " + reflAngle * 180/Math.PI + "\n";
			document.getElementById("log").value += "reflctnX " + ray1.reflctnX + " reflctnY " + ray1.reflctnY + "\n";*/
		}		
	}

	if ((intersect == false) &&
	    (refrStartX != prism1.side3StartX) || // ensure reflection side is not refraction side.
	    (refrStartY != prism1.side3StartY) ||
		(refrEndX != prism1.side3EndX) ||
		(refrEndY != prism1.side3EndY)){
		intersect = checkLineIntersection(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
		prism1.side3StartX, prism1.side3StartY, prism1.side3EndX, prism1.side3EndY);
		if (intersect){
			ray1.refrctnX = intrSecX;
			ray1.refrctnY = intrSecY;
			ray1.distance = Math.hypot(ray1.startX - ray1.refrctnX, ray1.startY - ray1.refrctnY);

			var intersecAngle = findLineAngle(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
											  prism1.side3StartX, prism1.side3StartY, prism1.side3EndX, prism1.side3EndY);
			var sideAngle = findPointAngle(prism1.side3StartX, prism1.side3StartY, prism1.side3EndX, prism1.side3EndY);
			var reflAngle = (sideAngle + intersecAngle);
			ray1.reflctnX = Number(ray1.refrctnX) + Number(Math.cos(reflAngle) * (infinite));
			ray1.reflctnY = Number(ray1.refrctnY) + Number(Math.sin(reflAngle) * (infinite));
			/*document.getElementById("log").value = "Side InterSecAngle " + intersecAngle * 180/Math.PI;
			document.getElementById("log").value += "\nsideAngle " + sideAngle * 180/Math.PI;
			document.getElementById("log").value += "\nreflAngle " + reflAngle * 180/Math.PI + "\n";
			document.getElementById("log").value += "reflctnX " + ray1.reflctnX + " reflctnY " + ray1.reflctnY + "\n";*/
		}	
	}

	if ((intersect == false) &&
	    (refrStartX != prism1.side4StartX) || // ensure reflection side is not refraction side.
	    (refrStartY != prism1.side4StartY) ||
		(refrEndX != prism1.side4EndX) ||
		(refrEndY != prism1.side4EndY)){
		intersect = checkLineIntersection(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
		prism1.side4StartX, prism1.side4StartY, prism1.side4EndX, prism1.side4EndY);
		if (intersect){
			ray1.refrctnX = intrSecX;
			ray1.refrctnY = intrSecY;
			ray1.distance = Math.hypot(ray1.startX - ray1.refrctnX, ray1.startY - ray1.refrctnY);

			var intersecAngle = findLineAngle(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
											  prism1.side4StartX, prism1.side4StartY, prism1.side4EndX, prism1.side4EndY);
			var sideAngle = findPointAngle(prism1.side4StartX, prism1.side4StartY, prism1.side4EndX, prism1.side4EndY);
			var reflAngle = (sideAngle + intersecAngle);
			ray1.reflctnX = Number(ray1.refrctnX) + Number(Math.cos(reflAngle) * (infinite));
			ray1.reflctnY = Number(ray1.refrctnY) + Number(Math.sin(reflAngle) * (infinite));
			/*document.getElementById("log").value = "Side InterSecAngle " + intersecAngle * 180/Math.PI;			
			document.getElementById("log").value += "\nsideAngle " + sideAngle * 180/Math.PI;
			document.getElementById("log").value += "\nreflAngle " + reflAngle * 180/Math.PI + "\n";
			document.getElementById("log").value += "reflctnX " + ray1.reflctnX + " reflctnY " + ray1.reflctnY + "\n";*/
		}
	}
}

function checkLineIntersection(line1StartX, line1StartY, line1EndX, line1EndY, line2StartX, line2StartY, line2EndX, line2EndY) {

	var intersects = false;
    var denominator, a, b, numerator1, numerator2;

    denominator = ((line2EndY - line2StartY) * (line1EndX - line1StartX)) - ((line2EndX - line2StartX) * (line1EndY - line1StartY));
	
    if (denominator == 0) {
        return intersects;
    }

    a = line1StartY - line2StartY;
    b = line1StartX - line2StartX;
    numerator1 = ((line2EndX - line2StartX) * a) - ((line2EndY - line2StartY) * b);
    numerator2 = ((line1EndX - line1StartX) * a) - ((line1EndY - line1StartY) * b);
    a = numerator1 / denominator;
    b = numerator2 / denominator;

    intrSecX = Number(line1StartX) + (a * (line1EndX - line1StartX));
	intrSecX = intrSecX.toFixed(0);
    intrSecY = Number(line1StartY) + (a * (line1EndY - line1StartY));
	intrSecY = intrSecY.toFixed(0);
	if ((a > 0 && a < 1) && (b > 0 && b < 1)){
		intersects = true;
		//document.getElementById("debug2").value = "Intersects " + lineIntrSecX + "," + lineIntrSecY;
	}
	else{
		//document.getElementById("debug2").value = "Do not Intersects " + lineIntrSecX + "," + lineIntrSecY;
	}
	//document.getElementById("log").value += "intersects " + intersects + "\n";
    return intersects;
}
*/
