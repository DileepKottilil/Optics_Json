//Declare an Empty Generic structure
var Gen_Structure = { No_of_Components: 0,
    Components : [] 
};

//Create Default strcuture of each Objects Components Lens,Mirror,BeamSplitter...etc

var Lens_obj = { "Name":"Lens", Property:{"X"=0,"Y"=0,"FocalLength"=0},Childs[] };
var  Mirror_obj = { "Name":"Mirror", Property:{"X"=0,"Y"=0,"FocalLength"=0},Childs[] };


/*After Simulate Button clicks, your control comes here and read each component based on
their X-Axis co-ordiante values in their incrementing order  Until Mirror or Beamsplitter kind of reflection capable Components comes in.
Why becuase these components can reflect light and there might be components intercepting that reflected light.So we might have to check 
the Y-Axis also in reference to the last read X-axis component and consider those components comes in Y-axis  as childs of the Reflection
generated component. */

/*Suppose you read Lens from canvas then you create a varaible of Lens from above Lens Object and change that components Attribute 
according to that in the canvas and push that Object into the Gen_Structure.*/

for Loop which traverse the elemnts in the Canvas elements and check the components 
	if (canvas_element.name == "Lens")  //Assuming canvas_element contains the component details that you read from Canvas
		{
			Lens_obj  temp_lens_obj
			temp_lens_obj.Property.X=canvas_element.getXAxisValue(); //psudo code of Canvas element
			temp_lens_obj.Property.Y= canvas_element.getYAxisValue();
			temp_lens_obj.Property.FocalLength= canvas_element.getFocalLength();
			Gen_Structure.Components.push(temp_lens_obj)
		}
/*Do the same for all the components and push in the Generic structure 
if any reflection capable components Comes in then We need to add the components comes in Y-axis as its Childs[] section. 	*/


