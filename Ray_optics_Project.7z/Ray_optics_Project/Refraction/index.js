class Ray
{
	constructor(){
        this.startX = 0;
        this.startY = 0;
        this.endX = 0;
        this.endY = 0;
        this.intrSecX = 0;
        this.intrSecY = 0;
        this.reflctnX = 0;
        this.reflctnY = 0;
        this.refrctnX = 0;
        this.refrctnY = 0;
		this.distance = 0;
	}
};

class Mirror
{
	constructor(){
		this.startX = 0;
		this.startY = 0;
		this.endX = 0;
		this.endY = 0;
	}
};
class Prism
{
	constructor(){
		this.side1StartX = 0;
		this.side1StartY = 0;
		this.side1EndX = 0;
		this.side1EndY = 0;
		this.side2StartX = 0;
		this.side2StartY = 0;
		this.side2EndX = 0;
		this.side2EndY = 0;
		this.side3StartX = 0;
		this.side3StartY = 0;
		this.side3EndX = 0;
		this.side3EndY = 0;
		this.side4StartX = 0;
		this.side4StartY = 0;
		this.side4EndX = 0;
		this.side4EndY = 0;	
	}
};

const ray1 = new Ray();
const mirror1 = new Mirror();
const prism1 = new Prism();

var intersectMirror = false;
var intersectPrism = false;
var intrSecX = 0;
var intrSecY = 0;

var isClicked = false;
var infinite = 0;

var isRaySelected = true;
var isMirrorSelected = false;
var isPrismSelected = false;

function onLoad() { 
	infinite = Math.hypot(window.innerWidth, window.innerHeight);
}

function selectTool(){
	var tool = document.getElementById("ray");
	isRaySelected = tool.checked;
	tool = document.getElementById("mirror");
	isMirrorSelected = tool.checked;
	tool = document.getElementById("prism");
	isPrismSelected = tool.checked;
}

function findPointAngle(x1, y1, x2, y2) {
  var dy = y2 - y1;
  var dx = x2 - x1;
  var radian = Math.atan2(dy, dx);
  return radian;
}

function findLineAngle(l1x1, l1y1, l1x2, l1y2, l2x1, l2y1, l2x2, l2y2) {
	var dAx = l1x2 - l1x1;
	var dAy = l1y2 - l1y1;
	var dBx = l2x2 - l2x1;
	var dBy = l2y2 - l2y1;
	var radian =  Math.atan2(dAx * dBy - dAy * dBx, dAx * dBx + dAy * dBy);
	return radian;
}

function canvasMouseDown(event) { 

	if (isRaySelected) {
		if (!isClicked){   //New ray is starting on canvas; initializing Ray.startX and Ray.startY
			ray1.startX = event.clientX;
			ray1.startY = event.clientY;
			ray1.distance = 0;
			isClicked = true;
			intersectMirror = false;
			intersectPrism = false;
		}
		else{	//Second time clicked on canvas. nothing to do (Fixes the Ray).
			isClicked = false;
		}
	}
	else if (isMirrorSelected) {
		if (!isClicked){   //New Mirror is starting on canvas; initializing Mirror StartX and StartY
			mirror1.startX = event.clientX;
			mirror1.startY = event.clientY;
			isClicked = true;
		}
		else{	//Second time clicked on canvas. nothing to do(Fixes the Mirror).
			isClicked = false;
		}
	}
	else if (isPrismSelected) {
		if (!isClicked){
			prism1.side1StartX = event.clientX;
			prism1.side1StartY = event.clientY;
			isClicked = true;
		}
		else{	//Second time clicked on canvas. nothing to do(Fixes the prism).
			isClicked = false;
		}
	}
}

function canvasMouseMove(event) { 
	if (isRaySelected) {
		if (isClicked){
			var angle = findPointAngle(ray1.startX, ray1.startY, event.clientX, event.clientY);
			ray1.endX = Math.cos(angle) * (infinite);
			ray1.endY = Math.sin(angle) * (infinite);
			checkMirrorIntersection();
			checkPrismIntersection();
			draw();
		}
	}
	else if (isMirrorSelected){
		if (isClicked){
			mirror1.endX = event.clientX;
			mirror1.endY = event.clientY;
			checkMirrorIntersection();
			draw();	
		}
	}
	else if (isPrismSelected){
		if (isClicked){
			prism1.side1EndX = event.clientX;
			prism1.side1EndY = event.clientY;
			checkPrismIntersection();
            draw();	
		}
	}
}

function draw(){
	var canvas = document.getElementById('mycanvas');
	var ctx = canvas.getContext('2d');
	ctx.clearRect(0, 0, canvas.width, canvas.height);

	ctx.beginPath();
	ctx.moveTo(ray1.startX, ray1.startY);
	
	if (intersectMirror || intersectPrism){
		ctx.lineTo(ray1.intrSecX, ray1.intrSecY);
		ctx.lineTo(ray1.refrctnX, ray1.refrctnY);
		//ctx.lineTo(ray1.reflctnX, ray1.reflctnY);
	}
	else{
		ctx.lineTo(ray1.endX, ray1.endY);
	}
	ctx.strokeStyle = "yellow";
	ctx.stroke();

	ctx.beginPath();
	ctx.moveTo(mirror1.startX, mirror1.startY);
	ctx.lineTo(mirror1.endX, mirror1.endY);
	ctx.strokeStyle = "white";
	ctx.stroke();
    drawPrism(ctx);
}

function drawPrism(ctx){
	var dx = 0;
	var dy = 0;
	var nextX = 0;
	var nextY = 0;
	var endX = prism1.side1EndX;
	var endY = prism1.side1EndY;
	var startX = prism1.side1StartX;
	var startY = prism1.side1StartY;
	
	ctx.beginPath();
	ctx.moveTo(startX, startY);
	ctx.lineTo(endX, endY);
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	
	ctx.lineTo(nextX, nextY);
	prism1.side2StartX = startX;
	prism1.side2StartY = startY;
	prism1.side2EndX = nextX;
	prism1.side2EndY = nextY;

	endX = prism1.side1StartX;
	endY = prism1.side1StartY;
	startX = nextX;
	startY = nextY;
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	
	ctx.lineTo(nextX, nextY);
	prism1.side3StartX = startX;
	prism1.side3StartY = startY;
	prism1.side3EndX = nextX;
	prism1.side3EndY = nextY;	

	endX = startX;
	endY = startY;
	startX = nextX;
	startY = nextY;
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	
	ctx.lineTo(nextX, nextY);
	prism1.side4StartX = startX;
	prism1.side4StartY = startY;
	prism1.side4EndX = nextX;
	prism1.side4EndY = nextY;	
	
	ctx.strokeStyle = "white";
	ctx.stroke();	
	ctx.closePath();
}

function checkMirrorIntersection() {
	intersectMirror = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, mirror1.startX, mirror1.startY, mirror1.endX, mirror1.endY);
	if (intersectMirror){
		ray1.intrSecX = intrSecX;
		ray1.intrSecY = intrSecY;
		ray1.distance = Math.hypot(ray1.startX - ray1.intrSecX, ray1.startY - ray1.intrSecY);

		var intersecAngle = findLineAngle(ray1.startX, ray1.startY, ray1.intrSecX, ray1.intrSecY, 
		                                  mirror1.startX, mirror1.startY, mirror1.endX, mirror1.endY);
		document.getElementById("log").value = "InterSecAngle " + intersecAngle * 180/Math.PI;
		var mirrorAngle = findPointAngle(mirror1.startX, mirror1.startY, mirror1.endX, mirror1.endY);
		document.getElementById("log").value += "\nmirrorAngle " + mirrorAngle * 180/Math.PI;
		var reflAngle = (mirrorAngle + intersecAngle) - 0.01; // 0.01 is to make perpendicular reflection on 90dgre
		document.getElementById("log").value += "\nreflAngle " + reflAngle * 180/Math.PI + "\n";
		ray1.reflctnX = Math.cos(reflAngle) * (infinite);
		ray1.reflctnY = Math.sin(reflAngle) * (infinite);
	}
	else{
		ray1.distance = 0;
	}
}

function checkPrismIntersection() {
	var dBx = 0;
	var dBy = 0;
	var intrSecX1 = 0;
	var intrSecY1 = 0;
	var intrSecX2 = 0;
	var intrSecY2 = 0;
	var intrSecX3 = 0;
	var intrSecY3 = 0;
	var intrSecX4 = 0;
	var intrSecY4 = 0;
	var distance1 = 0;
	var distance2 = 0;
	var distance3 = 0;
	var distance4 = 0;

	var refrStartX = 0;
	var refrStartY = 0;
	var refrEndX = 0;
	var refrEndY = 0;

	var reflStartX = 0;
	var reflStartY = 0;
	var reflEndX = 0;
	var reflEndY = 0;
	
	ray1.distance = 0;
	intersectPrism = false;
	
	var intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
	prism1.side1StartX, prism1.side1StartY,  prism1.side1EndX, prism1.side1EndY);
	if (intersect){
		ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		ray1.intrSecX = intrSecX;
		ray1.intrSecY = intrSecY;
		refrStartX = prism1.side1StartX;
		refrStartY = prism1.side1StartY;
		refrEndX = prism1.side1EndX;
		refrEndY = prism1.side1EndY;
	}

	var intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
	prism1.side2StartX, prism1.side2StartY,  prism1.side2EndX, prism1.side2EndY);
	
	if (intersect){
		var distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		if ((distance < ray1.distance) || (ray1.distance == 0)){
			ray1.distance = distance;
			ray1.intrSecX = intrSecX;
			ray1.intrSecY = intrSecY;
			refrStartX = prism1.side2StartX;
			refrStartY = prism1.side2StartY;
			refrEndX = prism1.side2EndX;
			refrEndY = prism1.side2EndY;
		}
	}
	intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
	prism1.side3StartX, prism1.side3StartY,  prism1.side3EndX, prism1.side3EndY);
	
	if (intersect){
		var distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		if ((distance < ray1.distance) || (ray1.distance == 0)){
			ray1.distance = distance;
			ray1.intrSecX = intrSecX;
			ray1.intrSecY = intrSecY;
			refrStartX = prism1.side3StartX;
			refrStartY = prism1.side3StartY;
			refrEndX = prism1.side3EndX;
			refrEndY = prism1.side3EndY;
		}
	}
	intersect = checkLineIntersection(ray1.startX, ray1.startY, ray1.endX, ray1.endY, 
	prism1.side4StartX, prism1.side4StartY,  prism1.side4EndX, prism1.side4EndY);
	
	if (intersect){
		var distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		if ((distance < ray1.distance) || (ray1.distance == 0)){
			ray1.distance = distance;
			ray1.intrSecX = intrSecX;
			ray1.intrSecY = intrSecY;
			refrStartX = prism1.side4StartX;
			refrStartY = prism1.side4StartY;
			refrEndX = prism1.side4EndX;
			refrEndY = prism1.side4EndY;
		}
	}	

	if (ray1.distance != 0){
		intersectPrism = true;
		document.getElementById("log").value = "Prism intersects \n";

		var intersecAngle = findLineAngle(ray1.startX, ray1.startY, ray1.intrSecX, ray1.intrSecY, 
		                                  refrStartX, refrStartY, refrEndX, refrEndY);
		document.getElementById("log").value += "Refl InterSecAngle " + intersecAngle * 180/Math.PI;
		var sideAngle = findPointAngle(refrStartX, refrStartY, refrEndX, refrEndY);
		document.getElementById("log").value += "\nsideAngle " + sideAngle * 180/Math.PI;
		var refrAangle = (sideAngle - intersecAngle); // TBD.
		document.getElementById("log").value += "\nrefrAangle " + refrAangle * 180/Math.PI + "\n";
		ray1.refrctnX = Math.cos(refrAangle) * (infinite);
		ray1.refrctnY = Math.sin(refrAangle) * (infinite);		
	}
	else{
		intersectPrism = false;
		document.getElementById("log").value = "";
	}
	
//Reflection
/*
	intersect = checkLineIntersection(ray1.intrSecX, ray1.intrSecY, ray1.refrctnX, ray1.refrctnY, 
	prism1.side1StartX, prism1.side1StartY,  prism1.side1EndX, prism1.side1EndY);
	
	if (intersect){
		//ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
		ray1.refrctnX = intrSecX;
		ray1.refrctnY = intrSecY;
		reflStartX = prism1.side1StartX;
		reflStartY = prism1.side1StartY;
		reflEndX = prism1.side1EndX;
		reflEndY = prism1.side1EndY;
	}
	else{
		intersect = checkLineIntersection(ray1.intrSecX, ray1.intrSecY, ray1.reflctnX, ray1.reflctnY, 
		prism1.side2StartX, prism1.side2StartY,  prism1.side2EndX, prism1.side2EndY);
		if (intersect){
			//ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
			ray1.refrctnX = intrSecX;
			ray1.refrctnY = intrSecY;
			reflStartX = prism1.side2StartX;
			reflStartY = prism1.side2StartY;
			reflEndX = prism1.side2EndX;
			reflEndY = prism1.side2EndY;
		}
		else{
			intersect = checkLineIntersection(ray1.intrSecX, ray1.intrSecY, ray1.reflctnX, ray1.reflctnY, 
			prism1.side3StartX, prism1.side3StartY,  prism1.side3EndX, prism1.side3EndY);
			if (intersect){
				//ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
				ray1.refrctnX = intrSecX;
				ray1.refrctnY = intrSecY;
				reflStartX = prism1.side3StartX;
				reflStartY = prism1.side3StartY;
				reflEndX = prism1.side3EndX;
				reflEndY = prism1.side3EndY;
			}
			else{
				intersect = checkLineIntersection(ray1.intrSecX, ray1.intrSecY, ray1.reflctnX, ray1.reflctnY, 
				prism1.side4StartX, prism1.side4StartY,  prism1.side4EndX, prism1.side4EndY);
				if (intersect){
					//ray1.distance = Math.hypot(ray1.startX - intrSecX, ray1.startY - intrSecY);
					ray1.refrctnX = intrSecX;
					ray1.refrctnY = intrSecY;
					reflStartX = prism1.side4StartX;
					reflStartY = prism1.side4StartY;
					reflEndX = prism1.side4EndX;
					reflEndY = prism1.side4EndY;
				}
			}
		}
	}
	if (intersect){
		var intersecAngle = findLineAngle(ray1.startX, ray1.startY, ray1.intrSecX, ray1.intrSecY, 
		                                  reflStartX, reflStartY, reflEndX, reflEndY);
		document.getElementById("log").value += "InterSecAngle " + intersecAngle * 180/Math.PI;
		var sideAngle = findPointAngle(refrStartX, refrStartY, refrEndX, refrEndY);
		document.getElementById("log").value += "\nsideAngle " + sideAngle * 180/Math.PI;
		var reflAngle = (sideAngle + intersecAngle) - 0.01; // 0.01 is to make perpendicular reflection on 90dgre
		document.getElementById("log").value += "\nreflAngle " + reflAngle * 180/Math.PI;
		ray1.refrctnX = Math.cos(reflAngle) * (infinite);
		ray1.refrctnY = Math.sin(reflAngle) * (infinite);	
	}
	*/
}

function checkLineIntersection(line1StartX, line1StartY, line1EndX, line1EndY, line2StartX, line2StartY, line2EndX, line2EndY) {

	var intersects = false;
    denominator = ((line2EndY - line2StartY) * (line1EndX - line1StartX)) - ((line2EndX - line2StartX) * (line1EndY - line1StartY));
	
    var denominator, a, b, numerator1, numerator2;
	var x = 0;
	var y = 0;
	
    if (denominator == 0) {
        return intersects;
    }

    a = line1StartY - line2StartY;
    b = line1StartX - line2StartX;
    numerator1 = ((line2EndX - line2StartX) * a) - ((line2EndY - line2StartY) * b);
    numerator2 = ((line1EndX - line1StartX) * a) - ((line1EndY - line1StartY) * b);
    a = numerator1 / denominator;
    b = numerator2 / denominator;

    intrSecX = line1StartX + (a * (line1EndX - line1StartX));
	intrSecX = intrSecX.toFixed(0);
    intrSecY = line1StartY + (a * (line1EndY - line1StartY));
	intrSecY = intrSecY.toFixed(0);
	if ((a > 0 && a < 1) && (b > 0 && b < 1)){
		intersects = true;
		//document.getElementById("debug2").value = "Intersects " + lineIntrSecX + "," + lineIntrSecY;
	}
	else{
		//document.getElementById("debug2").value = "Donot Intersects " + lineIntrSecX + "," + lineIntrSecY;
	}

    return intersects;
}

