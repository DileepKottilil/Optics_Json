// Defines the surfaces (lines) with endpoints and refractive index (ri) as arguments.

class Boundary{
    constructor(x1,y1,x2,y2,ri){
        this.a = createVector(x1,y1); //creating vector a for x1,y1 pixel point
        this.b = createVector(x2,y2);
        this.ri = ri;
    }
    // NOT USED
    updateWallPos(x1,y1,x2,y2){ // updates the intitial position of the particle source's position from createVector(width/2, height/2) to x,y

    this.a.set(x1, y1); // setting position
    this.b.set(x2, y2);
}
    // shows surfaces on the canvas
    show(){
        stroke(255);
		//document.getElementById("log").value += "Show this.a.x " + this.a.x + " " + this.a.y + " \n";
		//document.getElementById("log").value += "Show this.b.x " + this.b.x + " " + this.b.y + " \n";
        line(this.a.x,this.a.y,this.b.x,this.b.y);
    }

}