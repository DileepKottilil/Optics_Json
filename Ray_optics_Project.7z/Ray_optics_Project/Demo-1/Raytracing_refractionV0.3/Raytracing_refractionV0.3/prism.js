// Creating objects: LightRay, Prism
class LightRay
{
	constructor(){
        this.startX = 0;  // Starting point of LightRay
        this.startY = 0;
        this.intrSecX = 0; // Point at which LightRay intersects on Prism
        this.intrSecY = 0;
        this.refrctnX = 0; // End point of refracted ray
        this.refrctnY = 0;
        this.reflctnX = 0; // End point of reflected ray
        this.reflctnY = 0;
        this.endX = 0; // End point of ray if it is not reflected or refracted.
        this.endY = 0;
	
		this.distance = 0;  // Length of ray between ray-source and reflection/refraction point.
	}
};

class Prism
{
	constructor(){
		this.side1StartX = 0; // Starting point of Side1 of Prism
		this.side1StartY = 0;
		this.side1EndX = 0;   // End point of Side1
		this.side1EndY = 0;
		this.side2StartX = 0;  // Start point of Side2
		this.side2StartY = 0;
		this.side2EndX = 0;    // End point of Side2
		this.side2EndY = 0;
		this.side3StartX = 0;   // Start point of Side3
		this.side3StartY = 0;
		this.side3EndX = 0;    // End point of Side3
		this.side3EndY = 0;
		this.side4StartX = 0;   // Start point of Side4
		this.side4StartY = 0;
		this.side4EndX = 0;      // End point of Side4
		this.side4EndY = 0;	 
	}
};

function findPointAngle(x1, y1, x2, y2) {  // Finds angle between two points. 
  var dy = y2 - y1;
  var dx = x2 - x1;
  var radian = Math.atan2(dy, dx);
  return radian;
}

function findLineAngle(l1x1, l1y1, l1x2, l1y2, l2x1, l2y1, l2x2, l2y2) {// Finds angle between two lines. [angle between ray and prism surface]
	var dAx = l1x2 - l1x1;
	var dAy = l1y2 - l1y1;
	var dBx = l2x2 - l2x1;
	var dBy = l2y2 - l2y1;
	var radian =  Math.atan2(dAx * dBy - dAy * dBx, dAx * dBx + dAy * dBy);
	return radian;
}
