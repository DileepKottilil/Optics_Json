//Defines the point source (from where all rays are emerged). It takes divergence (div) of the source and raydensity (rayDen) as arguments.
class Particle{
    constructor(div,rayDen){
        this.pos = createVector(width/2, height/2); // create vector from pixels (0,0) to pixels (width/2, height/2)
        this.rays = []; // creating empty array for rays to be filled later.
        this.div = div;
        this.rayDen = rayDen;
        
        // The rays are created from the point source and filled them in the array 'this.rays' (NOTE: "new RAY" calls the class ray.js)
        for (let c = -this.div; c < this.div; c += this.rayDen){
            this.rays.push(new Ray(this.pos,radians(c)));
        }
    }

    //used to update the point source poition
    update(x,y){ // updates the intitial position of the particle source's position from createVector(width/2, height/2) to x,y

        this.pos.set(x, y); // setting position
    }

    /////////////////// MAIN PHYSICS ENGINE

    // Implemeted logic is given below:
    // 1. Take array of walls (surfaces). 2. Take each ray from the point source and cast it towards the wall with least distance from the point source. 
    // 3. Find the interection points (IP) for every ray, and plot lines from point source to these IPs.
    // 3. Next, rays are casted from these intersection points to all other walls (expect the wall where these rays are interected).
    // 4. Repeat points 2 and 3 (tagged as 'loop1' below) untill all intersection points are obtained on the canvas boundary walls.
    multiBoundaries(walls){ 
        
        let nullSet = [0, 1, 2, 3];
        let j = -1; 
        this.wallSet = [];
        this.wallSetIndex = [];
        let raysArray = []; // array of rays from source to walls

        for (let k = 0; k <= this.rays.length; k++){
            this.wallSet.push(-1);            
            this.wallSetIndex.push(-1);

        }
        // wallSet.fill(0, 0, this.rays.length); // fill with 0 from 0 to walls.rays
        wallsNull = walls;

        for (let rayf of this.rays){
            j += 1;
            let closestSet = [];
            

            let closest = null;
            let record = Infinity; 
            let i = -1; // to find the index corresponds to 'wall' in 'walls'

            
            

                for (let wall of wallsNull){
					if (wall.a.x == 0 && wall.b.x == 0 && wall.a.y == 0 && wall.b.y == 0) {
						//document.getElementById("log").value += "x1 == 0 && x2 == 0 && y1 == 0 && y2 == 0\n";
						continue;
					}
                    // let pt = ray.cast(wall);
                    const pt = rayf.cast(wall);
                    i += 1;
                    if (pt) { // pt can be undefined if no wall is detected on the ray path. So, 'if' statement assures rays that hit the wall.
                        // fill(255);
                        
                        const d = p5.Vector.dist(this.pos, pt); // set pt and pos as vectors and finding the dist btw particle pos vector and the current wall vector
                        
                        if (d < record) { // searching for the minimum distant wall from the pos
                            record = d;
                            closest = pt;

                            if (nullSet.includes(i)){
                                continue;
                            } else {
                            // this.wallSet[j].push(closest); // rays closeset values (intersection values)
                            // this.wallSetIndex[j].push(i); 
                            this.wallSet[j] = closest; // rays closeset values (intersection values)
                            this.wallSetIndex[j] = i; // boundry index for closest values
                            }
                           
                        }

    
                    }   
                  
                }
                
                if (closest){ // if closest is not null
                    stroke (255, 100);
                    line(this.pos.x, this.pos.y, closest.x, closest.y);

                    
                    //////////////NEW
                    raysArray.push(p5.Vector.sub(closest,this.pos)); // incident vector on the wall

                    // let pos1 = createVector(this.pos.x,this.pos.y);
                    // let closest1 = createVector(closest.x, closest.y);
                    // drawArrow(pos1,closest1,'red');
                    print(1);
                    
                   

                }
            
                
        }

        // print(this.wallSetIndex);
        this.wallSetIndex = particle.removeItemAll(this.wallSetIndex, -1); // wall indices of new set of intersection rays
        this.wallSet = particle.removeItemAll(this.wallSet, -1); // new set of rays interection position values

        // for (let kk = 0; kk < 2; kk++){
        
        let kk = -1;
        loop1:
        while(true){
            kk += 1;
            // this.wallSet1 = [];  
            let wallSetIndex1 = []; let rays1 = []; 
            let raysInter = []; // 
            // let raysInter1 = [];

           //
            // for(let k = 0; k < 3; k++) { ///PROBLEM
                // create new set of rays
                for (let m = 0; m < this.wallSet.length; m++){

                    let anglebtw = particle.findAngIncident(raysArray[m], p5.Vector.sub(walls[this.wallSetIndex[m]].a, walls[this.wallSetIndex[m]].b), walls[this.wallSetIndex[m]].ri); //////////////NEW

                    rays1.push(new Ray(this.wallSet[m], anglebtw)); //anglebtw in radians already. Transmitted ray vectors
                }
            raysArray.splice(0,raysArray.length); // empytying raysArray

                let i = -1;      
                for(let rayss of rays1) { // this for loop only draws one set of lines from one boudary to another
                    i += 1;
                    let closest = null;
                    let record = Infinity;
                    let j = -1;

                    
                        for (let wall of walls){ // walls
                            j += 1;
                            if (j == this.wallSetIndex[i]){ // avoiding the wall where the intersection is.
                                continue;
                            }
                            else{
                                // print(i,j);
                                let pt = createVector();
                                pt = particle.casting(rayss, wall); //casting inds the intersection point

                                if (pt){
                                    const d = p5.Vector.dist(this.wallSet[i], pt);//////////////////////////

                                    if (d < record) { // searching for the minimum distant wall from the pos
                                        record = d;
                                        closest = pt; // point of intersection
                                        // raysInter[i] = closest;
                                        // wallSetIndex1[i] = j;
                                        
                                        if (nullSet.includes(j)){
                                            raysInter[i] = closest;
                                            wallSetIndex1[i] = -1; // to be deleted after plotting correponsding line
                                            // raysInter.push(-1);// rays closeset values (intersection values). Changed this from raysInter to raysInter1 bcoz assigning values on 'raysInter' changes 'wallSet' values
                                            // wallSetIndex1.push(-1);
                                            continue;
                                        } else {
                                            raysInter[i] = closest;
                                            // if (kk < i){

                                            // }
                                            wallSetIndex1[i] = j;
                                            print(1);
                                        
                                        }


                                        // raysInter[i].push(closest);// rays closeset values (intersection values). Changed this from raysInter to raysInter1 bcoz assigning values on 'raysInter' changes 'wallSet' values
                                        // wallSetIndex1[i].push(j);  // boundry index for closest values
                                        // }
                                    
                                    }
                                    

                                }


                            }


                        } // wallSet is taken as all walls has to be taken again

                    if (closest){ // if closest is not null (i.e, ith ray is not casting to any walls)
                        stroke (255, 100);
                        // line(this.pos.x, this.pos.y, closest.x, closest.y);

                        let pos1 = createVector(this.wallSet[i].x, this.wallSet[i].y);
                        let closest1 = createVector(raysInter[i].x, raysInter[i].y);

                        line(pos1.x, pos1.y, closest1.x, closest1.y);

                        raysArray.push(p5.Vector.sub(closest1, pos1)); // 

                        // order of below 2 lines matters
                       
                        
                        // j = -1;
                        // this.wallSet[i] = raysInter[i];
                        // this.wallSetIndex[i] = this.wallSetIndex1[i];
                    }
                    ///after all rays

                    let indexes = particle.pickIndices(wallSetIndex1);
                    // let indexes = particle.getAllIndexes(wallSetIndex1, -1);
                    wallSetIndex1 = particle.pickElements(wallSetIndex1, indexes);
                    raysInter = particle.pickElements(raysInter, indexes);
                    print(0);


                    // if (wallSetIndex1[i] == -1){
                    //     raysInter.splice(i,1); // deleting the 'closest' (intersection point) from rayInter correponds to the terminal boundary.
                    //     wallSetIndex1.splice(i,1);

                    // }

                }
                
               

                if (raysInter.length == 0){
                    console.log('raysInter = 0');
                    // let wallSetIndex1 = []; rays1 = []; 
                    // let raysInter = []; //
                    // this.wallSetIndex = []; this.wallSet = [];

                    break loop1;

                } else {
                    print(1);
                this.wallSetIndex = wallSetIndex1.slice(0); // just taking the copy of RHS array to LHS array. Chanage in RHS array won't be reflected in LHS array
                
                this.wallSet = raysInter.slice(0); // transferring arrays from rayInter to this.wallSet

                // // Changing above RHS array
                // wallSetIndex1.splice(0,wallSetIndex1.length);
                // rays1.splice(0, rays1.length);
                // raysInter.splice(0,raysInter.length) // 
                }
            // } // ////////////FOR
        
        }
        // } // function 
        /////////////////////////////////
        
       
        
        
    }

    //works similar to cast() function in rays.js. NOTE: Both can be clubbed together later.
    casting(rayss, wall) {

        // points on the wall or Boundary class
        const x1 = wall.a.x; //const is local varisable inside 'wall'
        const x2 = wall.b.x;
        const y1 = wall.a.y;
        const y2 = wall.b.y;

        // points on rays
        const x3 = rayss.pos.x;
        const y3 = rayss.pos.y;
        const x4 = rayss.pos.x + rayss.dir.x;
        const y4 = rayss.pos.y + rayss.dir.y;

        const den = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4);
        if (den == 0) {
            return;
        }

        const t = ((x1-x3)*(y3-y4) - (y1-y3)*(x3-x4))/den;
        const u = -((x1-x2)*(y1-y3) - (y1-y2)*(x1-x3))/den;

        if (t > 0 && t <1 && u > 0) {
            const pt = createVector(); // initilaizing a pt vector            pt.x = x1 + t*(x2-x1);
            pt.y = y1 + t*(y2-y1);// definign intersection points pt with y and x compojnetns
            pt.x = x1 + t*(x2-x1);
            
            return pt;

    
        } else { 
            return;
        }


    }

    // picks indices from an array 'arr' for which elements are positive integers.
    pickIndices(arr){
        return arr.reduce((ret_arr, number, index) => {
            if (number >= 0) ret_arr.push(index)
            return ret_arr
        }, [])
    
    }

    // pick elements from array 'arr1' correponds to the array of index values 'ind'
    pickElements(arr1, ind){let arr = [];
        for (let p = 0; p < ind.length; p++) {
             arr.push(arr1[ind[p]]);
        }
        return arr;
    }
    
    // console.log(pos(tt))

    // getAllIndexes(arr, val) {
    //     let indexes = [],  p = -1;
    //     while ((p = arr.indexOf(val, p+1)) != -1){
    //         indexes.push(p);
    //     }
    //     return indexes;
    // }
    // deleteAllIndices(arr, ind){
    //     for (let p = 0; p < ind.length; p++) {
    //         arr.splice(ind[p],1);
    //     }
    //     return arr;
    // }

    //NOT USED
    removeItemAll(arr, value) {
        var i = 0;
        while (i < arr.length) {
            if (arr[i] === value) {
                arr.splice(i, 1);
            } else {
            ++i;
            }
        } return arr;
        }
    
    // angle between two lines. NEED TO BE UPDATED.
    findAngIncident(rayVec, wallVec, riV){
        let angleBtw = rayVec.angleBetween(wallVec);
        let angleBtwD  = degrees(angleBtw);
        if (abs(angleBtwD) > 90){
            angleBtwD = abs(angleBtwD) - 90; //ang btw rayVec and normal to wallVec
            return -asin(sin(radians(angleBtwD))/riV);
            // return Math.PI/3;
        } else {
             angleBtwD = 90 - abs(angleBtwD);
             return -asin(sin(radians(angleBtwD))/riV);
            // return Math.PI/3;
            }
         // in radians

    }

    // NOT USED
    show(){
        fill(255)
        ellipse(this.pos.x, this.pos.y, 8);

        for (let ray of this.rays){
            ray.show();
        }
    }



}