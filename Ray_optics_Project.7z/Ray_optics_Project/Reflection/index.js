var lineStartX = 0;
var lineStartY = 0;
var lineEndX = 0;
var lineEndY = 0;
var lineIntrSecX = 0;
var lineIntrSecY = 0;
var lineReflctnX = 0;
var lineReflctnY = 0;

var intersectMirror = false;
var intersectPrism = false;
var intersecAngle = 0;
var reflctnAngle = 0;

var isClicked = false;
var scrDiameter = 0;

var isRaySelected = true;
var isMirrorSelected = false;
var isPrismSelected = false;

var mirrorStartX = 0;
var mirrorStartY = 0;
var mirrorEndX = 0;
var mirrorEndY = 0;

var prismSide1StartX = 0;
var prismSide1StartY = 0;
var prismSide1EndX = 0;
var prismSide1EndY = 0;

var prismSide2StartX = 0;
var prismSide2StartY = 0;
var prismSide2EndX = 0;
var prismSide2EndY = 0;

var prismSide3StartX = 0;
var prismSide3StartY = 0;
var prismSide3EndX = 0;
var prismSide3EndY = 0;

var prismSide4StartX = 0;
var prismSide4StartY = 0;
var prismSide4EndX = 0;
var prismSide4EndY = 0;

function onLoad() { 
	scrDiameter = Math.sqrt(Math.pow(window.innerWidth, 2) + Math.pow(window.innerHeight, 2));
	document.getElementById("Diam").value = scrDiameter;
}

function selectTool(){
	var tool = document.getElementById("ray");
	isRaySelected = tool.checked;
	tool = document.getElementById("mirror");
	isMirrorSelected = tool.checked;
	tool = document.getElementById("prism");
	isPrismSelected = tool.checked;
}

function canvasMouseDown(event) { 
	var x = event.clientX; 
	var y = event.clientY; 

	if (isRaySelected) {
		if (!isClicked){   //New line is starting on canvas; initializing lineStartX and StartY
			lineStartX = x;
			lineStartY = y;
			isClicked = true;
			intersectMirror = false;
			intersectPrism = false;
		}
		else{	//Second time clicked on canvas. nothing to do (Fixes the line).
			isClicked = false;
		}
		//document.getElementById("debug").value = "Ray selected";
	}
	else if (isMirrorSelected) {
		if (!isClicked){   //New line is starting on canvas; initializing lineStartX and StartY
			mirrorStartX = x;
			mirrorStartY = y;
			isClicked = true;
		}
		else{	//Second time clicked on canvas. nothing to do(Fixes the mirror).
			isClicked = false;
		}
		//document.getElementById("debug").value = "Mirror selected";
	}
	else if (isPrismSelected) {
		if (!isClicked){
			prismSide1StartX = x;
			prismSide1StartY = y;
			isClicked = true;
		}
		else{	//Second time clicked on canvas. nothing to do(Fixes the prism).
			isClicked = false;
		}
		document.getElementById("debug").value = "Prism selected";
	}
}

function canvasMouseMove(event) { 
	if (isRaySelected) {
		if (isClicked){
			var x = event.clientX; 
			var y = event.clientY; 
			
			var xsign = (x < lineStartX)? -1 : 1;// To map to Cartesian coordinate, adjusting sign of x and y. 
			var ysign = (y < lineStartY)? -1 : 1;
			var oppSide = Math.abs(y - lineStartY);
			var adjSide = Math.abs(x - lineStartX);
			var rad = Math.atan(oppSide/adjSide);
			lineEndX = (scrDiameter * Math.cos(rad)) * xsign;
			lineEndY = (scrDiameter * Math.sin(rad)) * ysign;
			draw();
		}
	}
	else if (isMirrorSelected){
		if (isClicked){
			mirrorEndX = event.clientX;
			mirrorEndY = event.clientY;
			intersectMirror = checkLineIntersection(lineStartX, lineStartY, lineEndX, lineEndY, mirrorStartX, mirrorStartY, mirrorEndX, mirrorEndY);
			if (intersectMirror){
				var dAx = lineIntrSecX - lineStartX;
				var dAy = lineIntrSecY - lineStartY;
				var dBx = mirrorEndX - mirrorStartX;
				var dBy = mirrorEndY - mirrorStartY;
				intersecAngle =  Math.atan2(dAx * dBy - dAy * dBx, dAx * dBx + dAy * dBy);
				var reflAngle = (Math.PI) - intersecAngle;
	
				var degree_angle = intersecAngle * (180 / Math.PI);
				//document.getElementById("debug").value = "intersecAngle " + degree_angle;
				degree_angle = reflAngle * (180 / Math.PI);
				//document.getElementById("debug2").value = "reflAngle " + degree_angle;

				var cosValue = Math.cos(reflAngle);
				cosValue = cosValue.toFixed(2);
				var sinValue = Math.sin(reflAngle);
				sinValue = sinValue.toFixed(2);
				//document.getElementById("debug3").value = "cos " + (200 * cosValue) + " sin " + (200 * sinValue);
				lineReflctnY = Number(lineIntrSecY) + Number(200 * cosValue);
				lineReflctnX = Number(lineIntrSecX) - Number(200 * sinValue);
				//document.getElementById("debug4").value = "ReflctnX " + lineReflctnX + 
				//" ReflctnY " + lineReflctnY;
			}
			draw();	
		}
	}
	else if (isPrismSelected){
		if (isClicked){
			//document.getElementById("log").value = "";
			prismSide1EndX = event.clientX;
			prismSide1EndY = event.clientY;
			
			intersectPrism = checkLineIntersection(lineStartX, lineStartY, lineEndX, lineEndY, prismSide1StartX, prismSide1StartY, prismSide1EndX, prismSide1EndY);
			var dBx = 0;
			var dBy = 0;
			if (intersectPrism){
				dBx = prismSide1EndX - prismSide1StartX;
				dBy = prismSide1EndY - prismSide1StartY;			
			}
			else{
				intersectPrism = checkLineIntersection(lineStartX, lineStartY, lineEndX, lineEndY, prismSide2StartX, prismSide2StartY, prismSide2EndX, prismSide2EndY);
				
				if (intersectPrism){
					dBx = prismSide2EndX - prismSide2StartX;
					dBy = prismSide2EndY - prismSide2StartY;			
				}
				else{
					intersectPrism = checkLineIntersection(lineStartX, lineStartY, lineEndX, lineEndY, prismSide3StartX, prismSide3StartY, prismSide3EndX, prismSide3EndY);
				
					if (intersectPrism){
						dBx = prismSide3EndX - prismSide3StartX;
						dBy = prismSide3EndY - prismSide3StartY;			
					}
					else{
						intersectPrism = checkLineIntersection(lineStartX, lineStartY, lineEndX, lineEndY, prismSide4StartX, prismSide4StartY, prismSide4EndX, prismSide4EndY);
				
						if (intersectPrism){
							dBx = prismSide4EndX - prismSide4StartX;
							dBy = prismSide4EndY - prismSide4StartY;			
						}
					}
				}
			}
			if (intersectPrism){
				var dAx = lineIntrSecX - lineStartX;
				var dAy = lineIntrSecY - lineStartY;

				intersecAngle =  Math.atan2(dAx * dBy - dAy * dBx, dAx * dBx + dAy * dBy);
				var reflAngle = (Math.PI) - intersecAngle;
	
				var degree_angle = intersecAngle * (180 / Math.PI);
				//document.getElementById("debug").value = "intersecAngle " + degree_angle;
				degree_angle = reflAngle * (180 / Math.PI);
				//document.getElementById("debug2").value = "reflAngle " + degree_angle;

				var cosValue = Math.cos(reflAngle);
				cosValue = cosValue.toFixed(2);
				var sinValue = Math.sin(reflAngle);
				sinValue = sinValue.toFixed(2);
				//document.getElementById("debug3").value = "cos " + (200 * cosValue) + " sin " + (200 * sinValue);
				lineReflctnY = Number(lineIntrSecY) + Number(200 * cosValue);
				lineReflctnX = Number(lineIntrSecX) - Number(200 * sinValue);
				//document.getElementById("debug4").value = "ReflctnX " + lineReflctnX + 
				//" ReflctnY " + lineReflctnY;
			}			
            draw();	
		}
	}
}

function draw(){
	var canvas = document.getElementById('mycanvas');
	var ctx = canvas.getContext('2d');
	ctx.clearRect(0, 0, canvas.width, canvas.height);

	ctx.beginPath();
	ctx.moveTo(lineStartX, lineStartY);
	
	if (intersectMirror || intersectPrism){
		ctx.lineTo(lineIntrSecX, lineIntrSecY);
		ctx.lineTo(lineReflctnX, lineReflctnY);
	}
	else{
		ctx.lineTo(lineEndX, lineEndY);
	}
	ctx.strokeStyle = "yellow";
	ctx.stroke();
	
	ctx.beginPath();
	ctx.moveTo(mirrorStartX, mirrorStartY);
	ctx.lineTo(mirrorEndX, mirrorEndY);
	ctx.strokeStyle = "white";
	ctx.stroke();
    drawPrism(ctx);
}

function drawPrism(ctx){
	var dx = 0;
	var dy = 0;
	var nextX = 0;
	var nextY = 0;
	var endX = prismSide1EndX;
	var endY = prismSide1EndY;
	var startX = prismSide1StartX;
	var startY = prismSide1StartY;
	
	ctx.beginPath();
	ctx.moveTo(startX, startY);
	ctx.lineTo(endX, endY);
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	
	ctx.lineTo(nextX, nextY);
	prismSide2StartX = startX;
	prismSide2StartY = startY;
	prismSide2EndX = nextX;
	prismSide2EndY = nextY;
	
	document.getElementById("log").value = "";
	document.getElementById("log").value += "nextX " + nextX + " nextY " + nextY + "\n";

	endX = prismSide1StartX;
	endY = prismSide1StartY;
	startX = nextX;
	startY = nextY;
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	
	ctx.lineTo(nextX, nextY);
	prismSide3StartX = startX;
	prismSide3StartY = startY;
	prismSide3EndX = nextX;
	prismSide3EndY = nextY;	
	document.getElementById("log").value = "";
	document.getElementById("log").value += "nextX " + nextX + " nextY " + nextY + "\n";

	endX = startX;
	endY = startY;
	startX = nextX;
	startY = nextY;
	
	dx = (endX - startX);
	dy = (endY - startY);
	ctx.moveTo(startX, startY);
	nextX = Number(startX) + Number(dy);
	nextY = Number(startY) - Number(dx);
	
	ctx.lineTo(nextX, nextY);
	prismSide4StartX = startX;
	prismSide4StartY = startY;
	prismSide4EndX = nextX;
	prismSide4EndY = nextY;	
	
	document.getElementById("log").value = "";
	document.getElementById("log").value += "nextX " + nextX + " nextY " + nextY + "\n";
	ctx.strokeStyle = "white";
	ctx.stroke();	
	ctx.closePath();
}

function checkLineIntersection(line1StartX, line1StartY, line1EndX, line1EndY, line2StartX, line2StartY, line2EndX, line2EndY) {

    var denominator, a, b, numerator1, numerator2;
	var x = 0;
	var y = 0;
	var intersects = false;
	
    denominator = ((line2EndY - line2StartY) * (line1EndX - line1StartX)) - ((line2EndX - line2StartX) * (line1EndY - line1StartY));
	
    if (denominator == 0) {
        return intersects;
    }
	
    a = line1StartY - line2StartY;
    b = line1StartX - line2StartX;
    numerator1 = ((line2EndX - line2StartX) * a) - ((line2EndY - line2StartY) * b);
    numerator2 = ((line1EndX - line1StartX) * a) - ((line1EndY - line1StartY) * b);
    a = numerator1 / denominator;
    b = numerator2 / denominator;

    lineIntrSecX = line1StartX + (a * (line1EndX - line1StartX));
lineIntrSecX = lineIntrSecX.toFixed(0);
    lineIntrSecY = line1StartY + (a * (line1EndY - line1StartY));
lineIntrSecY = lineIntrSecY.toFixed(0);
	if ((a > 0 && a < 1) && (b > 0 && b < 1)){
		intersects = true;
		//document.getElementById("debug2").value = "Intersects " + lineIntrSecX + "," + lineIntrSecY;
	}
	else{
		//document.getElementById("debug2").value = "Donot Intersects " + lineIntrSecX + "," + lineIntrSecY;
	}
    return intersects;
};
